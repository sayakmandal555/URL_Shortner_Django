from django.shortcuts import render
from django.http import HttpResponse
def hello_world(request):
    return HttpResponse("Hello world!")
def home_page(request):
    return render(request,'index.html') #render return html page

# Create your views here.   save html file in templates folder in app and css or js file in static folder. first create static and template folder
# css file in static folder